import time
import random
import zlib
import socket
import logging
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import posixpath
from typing import Optional
import pandas as pd

from lakegen.generators.base import BaseGenerator
from lakegen.writers import OutputWriterFactory

from .entity.customer import Customer, pick_customer_seed
from .entity.web_order import WebOrder
from .entity.manufacturing_event import ManufacturingEvent
from .entity.production_line import PRODUCTION_LINES, generate_molds
from .entity.production_order import ProductionOrder
from .entity.inventory_transaction import InventoryTransaction
from .entity.quality_inspection import QualityInspection
from .entity.product_return import ProductReturn
from .entity.set_price_history import SetPriceHistory
from .entity.data_quality import DataQualityInjector

logger = logging.getLogger(__name__)


class LegoDataGen(BaseGenerator):
    TABLES = [
        "web_order",
        "web_order_line",
        "customer",
        "manufacturing_event",
        "production_order",
        "inventory_transaction",
        "quality_inspection",
        "product_return",
        "set_price_history",
        # Reference tables (written once):
        "colors",
        "parts",
        "sets",
        "themes",
        "part_categories",
        "inventories",
        "inventory_parts",
        "inventory_sets",
        "production_line",
        "mold",
    ]

    def __init__(
        self,
        target_folder_uri: str = None,
        output_type_map: Optional[dict] = None,
        kafka_connection_string: Optional[str] = None,
        concurrenct_threads: int = 1,
        sec_delay_between_batches: int = None,
        max_events_per_second: int = None,
        enable_data_quality_issues: bool = False,
        buffer_write_by_seconds: float = 0,
    ):
        super().__init__(target_folder_uri)
        self.output_type_map = output_type_map or {}
        self.kafka_connection_string = kafka_connection_string
        self.concurrenct_threads = concurrenct_threads
        self.sec_delay_between_batches = sec_delay_between_batches
        self.max_events_per_second = max_events_per_second
        self.enable_data_quality_issues = enable_data_quality_issues
        self.buffer_write_by_seconds = buffer_write_by_seconds

        # Load reference data from parquet files
        _data_dir = Path(__file__).parent / "data"
        self._colors = pd.read_parquet(_data_dir / "colors.parquet")
        self._parts = pd.read_parquet(_data_dir / "parts.parquet")
        self._sets = pd.read_parquet(_data_dir / "sets.parquet")
        self._themes = pd.read_parquet(_data_dir / "themes.parquet")
        self._part_categories = pd.read_parquet(_data_dir / "part_categories.parquet")
        self._inventories = pd.read_parquet(_data_dir / "inventories.parquet")
        self._inventory_parts = pd.read_parquet(_data_dir / "inventory_parts.parquet")
        self._inventory_sets = pd.read_parquet(_data_dir / "inventory_sets.parquet")

        # Convert to list of dicts for use by entity classes
        self._sets_catalog = self._sets.to_dict('records')
        self._parts_catalog = self._parts.to_dict('records')
        self._colors_catalog = self._colors.to_dict('records')

        # Create output writer factory
        self._writer_factory = OutputWriterFactory(
            target_folder_uri=target_folder_uri,
            kafka_connection_string=kafka_connection_string,
            system_id=None,
        )

        # Create directories for file-based outputs
        self._ensure_table_directories()

        # Thread control
        self._telemetry_threads = []
        self._telemetry_stop = threading.Event()
        self._telemetry_start_time = None
        self._total_order_count = 0
        self._total_manufacturing_event_count = 0
        self._system_id = zlib.crc32(socket.gethostname().encode()) & 0xFFFFFFFF
        self._customer_id_set = set()

        # Thread-safe locks for shared resources
        self._customer_set_lock = threading.Lock()

        # Production reference data
        self._production_lines = PRODUCTION_LINES

        # Generate molds from plastic parts (1 mold per active part)
        plastic_parts = [p for p in self._parts_catalog if p.get("part_material") == "Plastic"]
        self._molds = generate_molds(plastic_parts)

        # Data quality injector
        self._dq_injector = DataQualityInjector()

        # Price history (generated once)
        self._price_history_instance = SetPriceHistory()

        # Precompute Zipf popularity weights for set/part selection
        self._web_order_template = WebOrder()
        self._web_order_template.compute_catalog_weights(self._sets_catalog, self._parts_catalog)
        self._set_weights = self._web_order_template._set_weights
        self._part_weights = self._web_order_template._part_weights

        # Update factory with system_id now that it's initialized
        self._writer_factory.system_id = self._system_id

    def _ensure_table_directories(self):
        """Create output directories for all tables if they don't exist."""
        if self.target_folder_uri and self.fs:
            for table in self.TABLES:
                output_type = self.output_type_map.get(table, "json")
                if output_type in ["json", "parquet"]:
                    self.fs.mkdirs(posixpath.join(self.target_folder_uri, table), exist_ok=True)

    def _write_static_reference_data(self):
        """Write static reference data files."""
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="colors",
            format=self.output_type_map.get("colors", "json"),
            data=self._colors.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="parts",
            format=self.output_type_map.get("parts", "json"),
            data=self._parts.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="sets",
            format=self.output_type_map.get("sets", "json"),
            data=self._sets_catalog,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="themes",
            format=self.output_type_map.get("themes", "json"),
            data=self._themes.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="part_categories",
            format=self.output_type_map.get("part_categories", "json"),
            data=self._part_categories.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="inventories",
            format=self.output_type_map.get("inventories", "json"),
            data=self._inventories.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="inventory_parts",
            format=self.output_type_map.get("inventory_parts", "json"),
            data=self._inventory_parts.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="inventory_sets",
            format=self.output_type_map.get("inventory_sets", "json"),
            data=self._inventory_sets.to_dict('records'),
            skip_if_non_empty_root=True,
        )
        # Production lines
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="production_line",
            format=self.output_type_map.get("production_line", "json"),
            data=self._production_lines,
            skip_if_non_empty_root=True,
        )
        # Molds
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="mold",
            format=self.output_type_map.get("mold", "json"),
            data=self._molds,
            skip_if_non_empty_root=True,
        )
        # Set price history (SCD2 - generated once as historical data)
        price_history = self._price_history_instance.generate_price_history(self._sets_catalog)
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="set_price_history",
            format=self.output_type_map.get("set_price_history", "json"),
            data=price_history,
            skip_if_non_empty_root=True,
        )

    def _write_output_data(
        self,
        folder_uri: str,
        table_name: str,
        format: str,
        data: list,
        skip_if_non_empty_root: bool = False,
    ):
        if self.output_type_map.get(table_name, 1) is None:
            return None

        # Check if we should skip file-based writes for static data
        if skip_if_non_empty_root and format in ["json", "parquet"] and self.fs:
            table_folder_uri = posixpath.join(folder_uri, table_name)
            try:
                existing_file_count = len(self.fs.ls(table_folder_uri))
            except FileNotFoundError:
                existing_file_count = 0
            if existing_file_count > 0:
                return None

        # Get writer from factory
        format = format.lower()
        try:
            writer = self._writer_factory.get_writer(format)
        except ValueError as e:
            raise ValueError(f"Error getting writer for format '{format}': {e}")

        # Write data using the appropriate writer
        ts = int(time.time() * 1000)

        return writer.write(table_name=table_name, data=data, timestamp=ts)

    def _start_generator_thread(self, verbose=True):
        """Worker function to generate LEGO data until stop event is set."""
        total_manufacturing_event_count = 0
        start_time = time.time()

        # Accumulated buffers for buffer_write_by_seconds batching (file writes only)
        acc_web_order = []
        acc_web_order_line = []
        acc_customer = []
        acc_manufacturing_event = []
        acc_production_order = []
        acc_inventory_txn = []
        acc_quality_inspection = []
        acc_product_return = []
        last_flush_time = time.time()

        try:
            logger.info("[%s] Starting generator thread...", threading.current_thread().name)
            logger.debug("[%s] Stop event is set: %s", threading.current_thread().name, self._telemetry_stop.is_set())

            while not self._telemetry_stop.is_set():
                # Initialize per-iteration buffers
                web_order_buffer = []
                web_order_line_buffer = []
                customer_buffer = []
                manufacturing_event_buffer = []
                production_order_buffer = []
                inventory_txn_buffer = []
                quality_inspection_buffer = []
                product_return_buffer = []

                max_customers = min(
                    max(int(self._total_order_count**0.6), 10), 99_999_999
                )

                customer_instance = Customer()
                web_order_instance = WebOrder()
                manufacturing_event_instance = ManufacturingEvent()
                production_order_instance = ProductionOrder()
                inventory_txn_instance = InventoryTransaction()
                quality_inspection_instance = QualityInspection()
                product_return_instance = ProductReturn()

                # --- PRODUCTION ORDERS (2-5 per batch) ---
                for _ in range(random.randint(2, 5)):
                    po = production_order_instance._generate_production_order(
                        self._parts_catalog, self._colors_catalog, self._molds, self._production_lines
                    )
                    production_order_buffer.append(po)

                    # If completed, generate inventory receipt + scrap + QC
                    if po["Status"] == "completed":
                        receipt = inventory_txn_instance.generate_production_receipt(po, self._production_lines)
                        if receipt:
                            inventory_txn_buffer.append(receipt)

                        scrap = inventory_txn_instance.generate_scrap(po, self._production_lines)
                        if scrap:
                            inventory_txn_buffer.append(scrap)

                        inspection = quality_inspection_instance._generate_inspection(po)
                        quality_inspection_buffer.append(inspection)

                # --- WEB ORDERS (5-30 per batch) ---
                for _ in range(random.randint(5, 30)):
                    customer_seed = pick_customer_seed(max_customers)
                    customer = customer_instance._generate_customer(seed=customer_seed)

                    with self._customer_set_lock:
                        if customer["CustomerId"] not in self._customer_id_set:
                            self._customer_id_set.add(customer["CustomerId"])
                            customer_buffer.append(customer)

                    order = web_order_instance._generate_order(
                        customer, self._sets_catalog, self._parts_catalog,
                        set_weights=self._set_weights, part_weights=self._part_weights,
                    )
                    web_order_buffer.append(order)
                    web_order_line_buffer.extend(order.get("OrderLines", []))

                    # Generate ORDER_PICK inventory transactions for this order
                    picks = inventory_txn_instance.generate_order_picks(order, self._production_lines, self._colors_catalog)
                    inventory_txn_buffer.extend(picks)

                    # ~3% chance of generating a product return
                    if random.random() < 0.03:
                        ret = product_return_instance._generate_return(order)
                        if ret:
                            product_return_buffer.append(ret)

                # --- TRANSFERS & ADJUSTMENTS (occasional) ---
                if random.random() < 0.2:  # 20% of batches
                    transfers = inventory_txn_instance.generate_transfer(
                        self._parts_catalog, self._colors_catalog, self._production_lines
                    )
                    inventory_txn_buffer.extend(transfers)

                if random.random() < 0.1:  # 10% of batches
                    adj = inventory_txn_instance.generate_adjustment(
                        self._parts_catalog, self._colors_catalog, self._production_lines
                    )
                    inventory_txn_buffer.append(adj)

                # --- MANUFACTURING EVENTS (linked to production orders + background noise) ---
                # Generate events linked to in-progress/completed production orders
                for po in production_order_buffer:
                    if po["Status"] in ("in_progress", "completed") and po.get("ActualStart"):
                        linked_events = manufacturing_event_instance._generate_events_for_order(po)
                        manufacturing_event_buffer.extend(linked_events)

                # Background noise: standalone events from other machines
                noise_count = random.randint(5, 20)
                noise_events = manufacturing_event_instance._generate_events(
                    self._parts_catalog, self._colors_catalog, count=noise_count
                )
                manufacturing_event_buffer.extend(noise_events)

                # --- APPLY DATA QUALITY ISSUES ---
                if self.enable_data_quality_issues:
                    manufacturing_event_buffer = self._dq_injector.inject(manufacturing_event_buffer)
                    inventory_txn_buffer = self._dq_injector.inject(inventory_txn_buffer)
                    production_order_buffer = self._dq_injector.inject(production_order_buffer)

                # --- THROTTLING ---
                if self.max_events_per_second is not None and total_manufacturing_event_count > 0:
                    max_thread_eps = self.max_events_per_second / max(1, self.concurrenct_threads)
                    batch_event_count = len(manufacturing_event_buffer)
                    target_time_for_batch = batch_event_count / max_thread_eps

                    if verbose:
                        elapsed_time = time.time() - start_time
                        current_eps = total_manufacturing_event_count / elapsed_time if elapsed_time > 0 else 0
                        logger.info(
                            "[%s] Throttling: current_eps=%.2f, target=%.2f, sleeping %.3fs for %d events",
                            threading.current_thread().name, current_eps, max_thread_eps,
                            target_time_for_batch, batch_event_count,
                        )
                    time.sleep(target_time_for_batch)

                # --- WRITE / ACCUMULATE BUFFERS ---
                # For kafka outputs, write immediately. For file outputs, respect buffer_write_by_seconds.
                is_flush_due = (time.time() - last_flush_time) >= self.buffer_write_by_seconds

                # Accumulate into batch buffers
                acc_web_order.extend(web_order_buffer)
                acc_web_order_line.extend(web_order_line_buffer)
                acc_customer.extend(customer_buffer)
                acc_manufacturing_event.extend(manufacturing_event_buffer)
                acc_production_order.extend(production_order_buffer)
                acc_inventory_txn.extend(inventory_txn_buffer)
                acc_quality_inspection.extend(quality_inspection_buffer)
                acc_product_return.extend(product_return_buffer)

                # Write kafka tables immediately (not affected by buffer_write_by_seconds)
                kafka_tables = {
                    k for k, v in self.output_type_map.items() if v == "kafka"
                }
                for tbl, buf in [
                    ("customer", customer_buffer),
                    ("web_order", web_order_buffer),
                    ("web_order_line", web_order_line_buffer),
                    ("manufacturing_event", manufacturing_event_buffer),
                    ("production_order", production_order_buffer),
                    ("inventory_transaction", inventory_txn_buffer),
                    ("quality_inspection", quality_inspection_buffer),
                    ("product_return", product_return_buffer),
                ]:
                    if buf and tbl in kafka_tables:
                        self._write_output_data(
                            folder_uri=self.target_folder_uri,
                            table_name=tbl,
                            format="kafka",
                            data=buf,
                        )

                # Flush file-based writes when batch duration has elapsed
                if is_flush_due:
                    for tbl, buf in [
                        ("customer", acc_customer),
                        ("web_order", acc_web_order),
                        ("web_order_line", acc_web_order_line),
                        ("manufacturing_event", acc_manufacturing_event),
                        ("production_order", acc_production_order),
                        ("inventory_transaction", acc_inventory_txn),
                        ("quality_inspection", acc_quality_inspection),
                        ("product_return", acc_product_return),
                    ]:
                        fmt = self.output_type_map.get(tbl, "json")
                        if buf and fmt != "kafka":
                            self._write_output_data(
                                folder_uri=self.target_folder_uri,
                                table_name=tbl,
                                format=fmt,
                                data=buf,
                            )

                    # Reset accumulators
                    acc_web_order.clear()
                    acc_web_order_line.clear()
                    acc_customer.clear()
                    acc_manufacturing_event.clear()
                    acc_production_order.clear()
                    acc_inventory_txn.clear()
                    acc_quality_inspection.clear()
                    acc_product_return.clear()
                    last_flush_time = time.time()

                # --- UPDATE COUNTERS ---
                batch_order_count = len(web_order_buffer)
                self._total_order_count += batch_order_count
                batch_manufacturing_event_count = len(manufacturing_event_buffer)
                total_manufacturing_event_count += batch_manufacturing_event_count
                self._total_manufacturing_event_count += batch_manufacturing_event_count
                elapsed_time = time.time() - start_time
                eps = total_manufacturing_event_count / elapsed_time if elapsed_time > 0 else 0

                if verbose:
                    logger.info(
                        "[%s] Batch complete - Orders: %d, Customers: %d, "
                        "ProdOrders: %d, InvTxns: %d, QC: %d, Returns: %d, "
                        "Mfg Events: %d | Total Mfg Events: %d, EPS: %.2f",
                        threading.current_thread().name, batch_order_count,
                        len(customer_buffer), len(production_order_buffer),
                        len(inventory_txn_buffer), len(quality_inspection_buffer),
                        len(product_return_buffer), batch_manufacturing_event_count,
                        total_manufacturing_event_count, eps,
                    )

                if self.sec_delay_between_batches:
                    time.sleep(self.sec_delay_between_batches)

            # --- FINAL FLUSH: write any remaining accumulated data ---
            for tbl, buf in [
                ("customer", acc_customer),
                ("web_order", acc_web_order),
                ("web_order_line", acc_web_order_line),
                ("manufacturing_event", acc_manufacturing_event),
                ("production_order", acc_production_order),
                ("inventory_transaction", acc_inventory_txn),
                ("quality_inspection", acc_quality_inspection),
                ("product_return", acc_product_return),
            ]:
                fmt = self.output_type_map.get(tbl, "json")
                if buf and fmt != "kafka":
                    self._write_output_data(
                        folder_uri=self.target_folder_uri,
                        table_name=tbl,
                        format=fmt,
                        data=buf,
                    )

        except Exception:
            logger.error("[%s] Generator thread failed", threading.current_thread().name, exc_info=True)
            raise
        else:
            elapsed_time = time.time() - start_time
            eps = total_manufacturing_event_count / elapsed_time if elapsed_time > 0 else 0
            return total_manufacturing_event_count, eps

    def start(self, verbose=True, background=True):
        """
        Start data generator.

        Args:
            verbose: Print progress messages
            background: If True, run in background thread. If False, block until interrupted.

        Returns:
            (total_events, total_eps) if background=False, otherwise None
        """
        if self._telemetry_threads and any(
            t.is_alive() for t in self._telemetry_threads
        ):
            logger.warning("Generator already running.")
            return

        # Write static reference data
        self._ensure_table_directories()
        self._write_static_reference_data()

        # Clear stop event for new run
        self._telemetry_stop.clear()
        self._total_manufacturing_event_count = 0
        self._telemetry_start_time = time.time()

        def _runner():
            results = []
            start_time = time.time()

            with ThreadPoolExecutor(max_workers=self.concurrenct_threads) as executor:
                futures = [
                    executor.submit(self._start_generator_thread, verbose)
                    for _ in range(self.concurrenct_threads)
                ]
                try:
                    for future in as_completed(futures):
                        results.append(future.result())
                except KeyboardInterrupt:
                    logger.info("Background thread received interrupt. Stopping all workers...")
                    self._telemetry_stop.set()
                    for future in futures:
                        try:
                            results.append(future.result())
                        except Exception:
                            logger.error("Thread terminated with error", exc_info=True)

            total_events = sum(r[0] for r in results) if results else 0
            total_elapsed = time.time() - start_time
            total_eps = total_events / total_elapsed if total_elapsed > 0 else 0
            logger.info("[Runner] exited: total_events=%d, eps=%.2f", total_events, total_eps)

        if background:
            thread = threading.Thread(target=_runner, name="Runner", daemon=False)
            thread.start()
            self._telemetry_threads = [thread]
            logger.info("Generator started in background with %d concurrent worker(s).", self.concurrenct_threads)
            logger.info("Call gen.stop() to stop generation.")
        else:
            logger.info("Generator starting with %d concurrent worker(s).", self.concurrenct_threads)
            logger.info("Interrupt the process to stop generation.")
            _runner()

    def stop(self, timeout=10):
        """Signal the background producer to stop and join all threads."""
        if not self._telemetry_threads:
            logger.info("Generator not running.")
            return

        logger.info("Stopping generator...")
        self._telemetry_stop.set()

        for thread in self._telemetry_threads:
            thread.join(timeout=timeout)
            if thread.is_alive():
                logger.warning(
                    "Thread %s is taking longer to stop; it will exit after the current batch.",
                    thread.name,
                )

        if not any(t.is_alive() for t in self._telemetry_threads):
            logger.info("Generator stopped.")

        self._telemetry_threads = []

        # Close all writers
        self._writer_factory.close_all()

    def status(self):
        """Check if generator is currently running and print metrics."""
        is_running = bool(self._telemetry_threads) and any(
            t.is_alive() for t in self._telemetry_threads
        )

        if is_running:
            elapsed_time = (
                time.time() - self._telemetry_start_time
                if self._telemetry_start_time
                else 0
            )
            eps = self._total_manufacturing_event_count / elapsed_time if elapsed_time > 0 else 0
            logger.info(
                "Generator running: total_events=%d, eps=%.2f, elapsed=%.1fs",
                self._total_manufacturing_event_count, eps, elapsed_time,
            )
        else:
            logger.info("Generator not running.")

        return is_running
