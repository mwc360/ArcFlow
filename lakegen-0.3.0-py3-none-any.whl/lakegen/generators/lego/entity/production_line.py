"""Static reference data for LEGO production lines and molds."""

import random

# ---------------------------------------------------------------------------
# Production Lines
# ---------------------------------------------------------------------------

PRODUCTION_LINES = [
    # Billund, Denmark (headquarters) - 12 lines
    {"LineId": "LINE-BIL-01", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 25000, "InstalledYear": 2005, "LastMaintenance": "2026-01-15"},
    {"LineId": "LINE-BIL-02", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 28000, "InstalledYear": 2008, "LastMaintenance": "2026-02-20"},
    {"LineId": "LINE-BIL-03", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 32000, "InstalledYear": 2012, "LastMaintenance": "2025-11-10"},
    {"LineId": "LINE-BIL-04", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 30000, "InstalledYear": 2015, "LastMaintenance": "2025-09-05"},
    {"LineId": "LINE-BIL-05", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 35000, "InstalledYear": 2019, "LastMaintenance": "2026-03-01"},
    {"LineId": "LINE-BIL-06", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 27000, "InstalledYear": 2003, "LastMaintenance": "2025-12-18"},
    {"LineId": "LINE-BIL-07", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 26000, "InstalledYear": 1998, "LastMaintenance": "2025-08-22"},
    {"LineId": "LINE-BIL-08", "Plant": "Billund", "CellType": "injection_molding", "Capacity": 31000, "InstalledYear": 2021, "LastMaintenance": "2026-04-12"},
    {"LineId": "LINE-BIL-09", "Plant": "Billund", "CellType": "decoration", "Capacity": 12000, "InstalledYear": 2010, "LastMaintenance": "2025-10-30"},
    {"LineId": "LINE-BIL-10", "Plant": "Billund", "CellType": "decoration", "Capacity": 14000, "InstalledYear": 2016, "LastMaintenance": "2026-01-25"},
    {"LineId": "LINE-BIL-11", "Plant": "Billund", "CellType": "assembly", "Capacity": 8000, "InstalledYear": 2014, "LastMaintenance": "2025-07-14"},
    {"LineId": "LINE-BIL-12", "Plant": "Billund", "CellType": "packaging", "Capacity": 10000, "InstalledYear": 2017, "LastMaintenance": "2026-02-08"},

    # Monterrey, Mexico - 8 lines
    {"LineId": "LINE-MTY-01", "Plant": "Monterrey", "CellType": "injection_molding", "Capacity": 30000, "InstalledYear": 2013, "LastMaintenance": "2025-11-20"},
    {"LineId": "LINE-MTY-02", "Plant": "Monterrey", "CellType": "injection_molding", "Capacity": 28000, "InstalledYear": 2014, "LastMaintenance": "2026-01-10"},
    {"LineId": "LINE-MTY-03", "Plant": "Monterrey", "CellType": "injection_molding", "Capacity": 33000, "InstalledYear": 2018, "LastMaintenance": "2025-12-05"},
    {"LineId": "LINE-MTY-04", "Plant": "Monterrey", "CellType": "injection_molding", "Capacity": 29000, "InstalledYear": 2020, "LastMaintenance": "2026-03-15"},
    {"LineId": "LINE-MTY-05", "Plant": "Monterrey", "CellType": "injection_molding", "Capacity": 34000, "InstalledYear": 2022, "LastMaintenance": "2026-04-01"},
    {"LineId": "LINE-MTY-06", "Plant": "Monterrey", "CellType": "decoration", "Capacity": 11000, "InstalledYear": 2016, "LastMaintenance": "2025-10-12"},
    {"LineId": "LINE-MTY-07", "Plant": "Monterrey", "CellType": "assembly", "Capacity": 7500, "InstalledYear": 2019, "LastMaintenance": "2026-02-28"},
    {"LineId": "LINE-MTY-08", "Plant": "Monterrey", "CellType": "packaging", "Capacity": 9500, "InstalledYear": 2021, "LastMaintenance": "2025-09-18"},

    # Jiaxing, China - 10 lines
    {"LineId": "LINE-JXG-01", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 32000, "InstalledYear": 2016, "LastMaintenance": "2026-01-08"},
    {"LineId": "LINE-JXG-02", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 35000, "InstalledYear": 2017, "LastMaintenance": "2025-11-25"},
    {"LineId": "LINE-JXG-03", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 30000, "InstalledYear": 2018, "LastMaintenance": "2026-03-20"},
    {"LineId": "LINE-JXG-04", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 33000, "InstalledYear": 2019, "LastMaintenance": "2025-12-14"},
    {"LineId": "LINE-JXG-05", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 28000, "InstalledYear": 2020, "LastMaintenance": "2026-02-05"},
    {"LineId": "LINE-JXG-06", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 31000, "InstalledYear": 2022, "LastMaintenance": "2026-04-18"},
    {"LineId": "LINE-JXG-07", "Plant": "Jiaxing", "CellType": "injection_molding", "Capacity": 34000, "InstalledYear": 2024, "LastMaintenance": "2026-05-01"},
    {"LineId": "LINE-JXG-08", "Plant": "Jiaxing", "CellType": "decoration", "Capacity": 13000, "InstalledYear": 2019, "LastMaintenance": "2025-10-22"},
    {"LineId": "LINE-JXG-09", "Plant": "Jiaxing", "CellType": "assembly", "Capacity": 8500, "InstalledYear": 2021, "LastMaintenance": "2026-01-30"},
    {"LineId": "LINE-JXG-10", "Plant": "Jiaxing", "CellType": "packaging", "Capacity": 9000, "InstalledYear": 2023, "LastMaintenance": "2026-03-10"},

    # Nyíregyháza, Hungary - 6 lines
    {"LineId": "LINE-NYR-01", "Plant": "Nyíregyháza", "CellType": "injection_molding", "Capacity": 26000, "InstalledYear": 2009, "LastMaintenance": "2025-08-15"},
    {"LineId": "LINE-NYR-02", "Plant": "Nyíregyháza", "CellType": "injection_molding", "Capacity": 29000, "InstalledYear": 2011, "LastMaintenance": "2026-01-20"},
    {"LineId": "LINE-NYR-03", "Plant": "Nyíregyháza", "CellType": "injection_molding", "Capacity": 27000, "InstalledYear": 2015, "LastMaintenance": "2025-11-02"},
    {"LineId": "LINE-NYR-04", "Plant": "Nyíregyháza", "CellType": "injection_molding", "Capacity": 31000, "InstalledYear": 2020, "LastMaintenance": "2026-02-14"},
    {"LineId": "LINE-NYR-05", "Plant": "Nyíregyháza", "CellType": "decoration", "Capacity": 12500, "InstalledYear": 2013, "LastMaintenance": "2025-09-28"},
    {"LineId": "LINE-NYR-06", "Plant": "Nyíregyháza", "CellType": "assembly", "Capacity": 7000, "InstalledYear": 2018, "LastMaintenance": "2026-03-05"},
]

# ---------------------------------------------------------------------------
# Molds — one per distinct part in production
# ---------------------------------------------------------------------------

MOLD_MATERIALS = ["P20 Steel", "H13 Steel", "S136 Stainless", "Beryllium Copper"]
CAVITY_COUNTS = [1, 2, 4, 8, 16]
MOLD_STATUSES = ["active", "maintenance", "retired", "conditioning"]

# Number of parts considered "in active production"
_ACTIVE_PART_COUNT = 3500
# Number of recently-retired parts that still have molds on record
_RETIRED_PART_COUNT = 500
# Top N popular parts that get duplicate molds for extra capacity
_DUPLICATE_MOLD_TOP_N = 200


def generate_molds(plastic_parts: list) -> list:
    """Generate molds from the plastic parts catalog.

    Each currently-manufactured part gets one mold. The most popular parts
    get 2-3 duplicate molds. Recently-retired parts get retired molds.

    Args:
        plastic_parts: List of part dicts filtered to part_material == 'Plastic'

    Returns:
        List of mold dicts with PartNum assigned from the catalog.
    """
    rng = random.Random(42)

    # Deterministic shuffle to select active/retired subsets
    shuffled = plastic_parts.copy()
    rng.shuffle(shuffled)

    active_parts = shuffled[:_ACTIVE_PART_COUNT]
    retired_parts = shuffled[_ACTIVE_PART_COUNT:_ACTIVE_PART_COUNT + _RETIRED_PART_COUNT]

    injection_lines = [l["LineId"] for l in PRODUCTION_LINES if l["CellType"] == "injection_molding"]
    molds = []
    mold_idx = 0

    def _make_mold(part_num, status, rng):
        nonlocal mold_idx
        mold_idx += 1

        max_shots = rng.randint(500_000, 2_000_000)
        if status == "retired":
            current_shots = rng.randint(int(max_shots * 0.85), max_shots)
        elif status == "maintenance":
            current_shots = rng.randint(int(max_shots * 0.7), int(max_shots * 0.95))
        else:
            current_shots = rng.randint(0, int(max_shots * 0.85))

        assigned_line = None
        if status == "active":
            assigned_line = rng.choice(injection_lines)
        elif status == "conditioning":
            assigned_line = rng.choice(injection_lines)

        last_resurfaced = (
            f"{rng.randint(2023, 2026)}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}"
            if current_shots > max_shots * 0.3 and rng.random() < 0.6
            else None
        )

        return {
            "MoldId": f"MLD-{mold_idx:05d}",
            "PartNum": part_num,
            "CavityCount": rng.choices(CAVITY_COUNTS, weights=[5, 15, 35, 30, 15])[0],
            "Material": rng.choices(MOLD_MATERIALS, weights=[40, 30, 20, 10])[0],
            "MaxShots": max_shots,
            "CurrentShots": current_shots,
            "Status": status,
            "CommissionDate": f"{rng.randint(2000, 2024)}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}",
            "LastResurfaced": last_resurfaced,
            "AssignedLineId": assigned_line,
        }

    # Active parts: 1 mold each
    for part in active_parts:
        part_num = part.get("part_num", part.get("PartNum"))
        # Randomize status: mostly active, some in maintenance/conditioning
        status = rng.choices(
            ["active", "maintenance", "conditioning"],
            weights=[85, 10, 5],
        )[0]
        molds.append(_make_mold(part_num, status, rng))

    # Top popular parts get duplicate molds (2nd or 3rd copy)
    for part in active_parts[:_DUPLICATE_MOLD_TOP_N]:
        part_num = part.get("part_num", part.get("PartNum"))
        molds.append(_make_mold(part_num, "active", rng))
        # Top 50 get a third mold
        if active_parts.index(part) < 50:
            molds.append(_make_mold(part_num, "active", rng))

    # Retired parts: retired molds
    for part in retired_parts:
        part_num = part.get("part_num", part.get("PartNum"))
        molds.append(_make_mold(part_num, "retired", rng))

    return molds
