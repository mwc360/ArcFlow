import random
import uuid
from datetime import datetime, timedelta


RETURN_REASONS = ["missing_parts", "damaged", "wrong_item", "changed_mind", "defective"]
RETURN_STATUSES = ["initiated", "received", "inspected", "refunded", "rejected"]


class ProductReturn:
    """Generates product returns for ~3% of orders."""

    def _generate_return(self, order: dict) -> dict:
        """
        Generate a return for a given web order.
        
        Args:
            order: A web_order dict with OrderId, CustomerId, OrderDate, OrderLines, OrderTotal
        
        Returns:
            Dict with return fields
        """
        # Pick a random line from the order to return
        order_lines = order.get("OrderLines", [])
        if not order_lines:
            return None
        
        line = random.choice(order_lines)
        
        # Return date: 1-30 days after order
        order_date = datetime.fromisoformat(order.get("OrderDate", datetime.now().isoformat()))
        return_date = order_date + timedelta(days=random.randint(1, 30))
        
        # Quantity returned (1 to full line quantity)
        line_qty = line.get("Quantity", 1)
        return_qty = random.randint(1, max(1, line_qty))
        
        # Refund: partial or full based on reason
        reason = random.choices(
            RETURN_REASONS,
            weights=[25, 20, 10, 30, 15],
        )[0]
        
        unit_price = line.get("UnitPrice", 29.99)
        if reason == "changed_mind":
            # Restocking fee: 85% refund
            refund = round(unit_price * return_qty * 0.85, 2)
        elif reason == "rejected":
            refund = 0.0
        else:
            refund = round(unit_price * return_qty, 2)
        
        # Status: weighted toward later stages (most returns are processed)
        status = random.choices(
            RETURN_STATUSES,
            weights=[5, 10, 15, 60, 10],
        )[0]
        
        return {
            "ReturnId": str(uuid.uuid4()),
            "OrderId": order.get("OrderId"),
            "CustomerId": order.get("CustomerId"),
            "ReturnDate": return_date.date().isoformat(),
            "Reason": reason,
            "SetNum": line.get("SetNum"),
            "PartNum": line.get("PartNum"),
            "Quantity": return_qty,
            "RefundAmount": refund,
            "Status": status,
        }
