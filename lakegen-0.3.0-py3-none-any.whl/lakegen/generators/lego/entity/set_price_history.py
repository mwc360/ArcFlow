import random
from datetime import date, timedelta


CURRENCIES = ["USD", "EUR", "GBP", "DKK"]
CHANGE_REASONS = ["new_release", "price_increase", "promotion", "retirement_sale"]


class SetPriceHistory:
    """Generates SCD Type 2 price history for LEGO sets."""

    def generate_price_history(self, sets_catalog: list, max_sets: int = 500) -> list:
        """
        Generate price history records for a subset of sets.
        Called once during static data write to create historical price data.
        
        Args:
            sets_catalog: List of set dicts from parquet
            max_sets: How many sets to generate history for
        
        Returns:
            List of price history records (multiple per set = SCD2)
        """
        records = []
        sample_sets = random.sample(sets_catalog, min(max_sets, len(sets_catalog)))
        
        for s in sample_sets:
            set_num = s.get("set_num", s.get("SetNum"))
            year = s.get("year", 2020)
            num_parts = s.get("num_parts", 100)
            
            # Base price correlated with num_parts (roughly $0.10-0.14 per part)
            base_price = round(num_parts * random.uniform(0.10, 0.14), 2)
            base_price = max(4.99, min(base_price, 849.99))
            
            # Generate 1-4 price periods per set
            num_changes = random.choices([1, 2, 3, 4], weights=[30, 40, 20, 10])[0]
            
            # Start date: approximate release year
            start_date = date(min(max(year, 2015), 2025), random.randint(1, 12), random.randint(1, 28))
            current_price = base_price
            
            for i in range(num_changes):
                # Duration of this price period: 3-18 months
                duration_days = random.randint(90, 540)
                end_date = start_date + timedelta(days=duration_days)
                
                # Don't go past today
                if end_date > date(2026, 5, 8):
                    end_date = None  # current price
                
                if i == 0:
                    reason = "new_release"
                elif end_date is None:
                    reason = random.choice(["price_increase", "retirement_sale"])
                else:
                    reason = random.choices(
                        CHANGE_REASONS,
                        weights=[5, 40, 35, 20],
                    )[0]
                
                for currency in CURRENCIES:
                    # Exchange rates (approximate)
                    fx = {"USD": 1.0, "EUR": 0.92, "GBP": 0.79, "DKK": 6.85}
                    local_price = round(current_price * fx[currency], 2)
                    
                    records.append({
                        "SetNum": set_num,
                        "Price": local_price,
                        "Currency": currency,
                        "EffectiveFrom": start_date.isoformat(),
                        "EffectiveTo": end_date.isoformat() if end_date else None,
                        "ChangeReason": reason,
                    })
                
                if end_date is None:
                    break
                
                # Next period: adjust price
                if reason == "promotion":
                    current_price = round(current_price * random.uniform(0.75, 0.90), 2)
                elif reason == "price_increase":
                    current_price = round(current_price * random.uniform(1.05, 1.15), 2)
                elif reason == "retirement_sale":
                    current_price = round(current_price * random.uniform(0.60, 0.80), 2)
                
                start_date = end_date + timedelta(days=1)
        
        return records
