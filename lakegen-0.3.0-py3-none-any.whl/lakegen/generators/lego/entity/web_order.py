import random
import uuid
from datetime import date, datetime, timedelta

import numpy as np


# Monthly seasonal multipliers (index 0 = Jan)
_MONTHLY_WEIGHTS = [0.6, 0.6, 0.8, 0.9, 0.9, 1.1, 1.1, 1.1, 0.9, 1.0, 1.4, 1.5]

# Day-of-week multipliers (0=Mon ... 6=Sun)
_DOW_WEIGHTS = [0.8, 0.8, 0.9, 0.9, 1.0, 1.3, 1.3]

# Hourly multipliers (index 0 = midnight)
_HOUR_WEIGHTS = [
    0.1, 0.05, 0.05, 0.05, 0.1, 0.2,   # 0-5
    0.4, 0.6, 0.8, 1.0, 1.3, 1.3,       # 6-11
    1.2, 1.3, 1.2, 1.0, 0.9, 0.8,       # 12-17
    0.9, 1.2, 1.3, 1.3, 1.0, 0.5,       # 18-23
]

_SOURCE_OPTIONS = ["Web", "Mobile", "InStore"]
_SOURCE_WEIGHTS = [0.55, 0.35, 0.10]


def _compute_zipf_weights(n: int, alpha: float) -> list:
    """Compute normalized Zipf weights for n items."""
    if n == 0:
        return []
    ranks = np.arange(1, n + 1, dtype=np.float64)
    weights = 1.0 / np.power(ranks, alpha)
    total = weights.sum()
    return (weights / total).tolist()


class WebOrder:
    def __init__(self):
        self._set_weights: list = []
        self._part_weights: list = []
        self._day_weights_cache: dict = {}

    def compute_catalog_weights(self, sets_catalog: list, parts_catalog: list) -> None:
        """Precompute Zipf popularity weights for catalogs."""
        self._set_weights = _compute_zipf_weights(len(sets_catalog), alpha=1.2)
        self._part_weights = _compute_zipf_weights(len(parts_catalog), alpha=1.5)

    def _pick_order_date(self) -> str:
        """Pick an order date+time using seasonal, day-of-week, and hourly patterns."""
        today = date.today()
        start_of_year = date(today.year, 1, 1)
        total_days = (today - start_of_year).days
        if total_days == 0:
            total_days = 1

        # Build per-day weights combining month and day-of-week factors
        cache_key = (today.year, total_days)
        if cache_key not in self._day_weights_cache:
            day_weights = []
            for d in range(total_days):
                candidate = start_of_year + timedelta(days=d)
                month_w = _MONTHLY_WEIGHTS[candidate.month - 1]
                dow_w = _DOW_WEIGHTS[candidate.weekday()]
                day_weights.append(month_w * dow_w)
            self._day_weights_cache[cache_key] = day_weights

        day_weights = self._day_weights_cache[cache_key]
        chosen_day_offset = random.choices(range(total_days), weights=day_weights, k=1)[0]
        chosen_date = start_of_year + timedelta(days=chosen_day_offset)

        # Pick hour using hourly weights
        hour = random.choices(range(24), weights=_HOUR_WEIGHTS, k=1)[0]
        minute = random.randint(0, 59)
        second = random.randint(0, 59)

        order_dt = datetime(
            chosen_date.year, chosen_date.month, chosen_date.day, hour, minute, second
        )
        return order_dt.isoformat()

    def _get_num_lines(self, customer: dict) -> int:
        """Determine order line count, correlated with customer loyalty tier."""
        tier = customer.get("LoyaltyTier", customer.get("loyalty_tier", "")).lower()
        if tier in ("vip", "gold"):
            return random.randint(3, 12)
        elif tier in ("silver",):
            return random.randint(2, 8)
        else:
            return random.randint(1, 5)

    def _generate_order(
        self,
        customer: dict,
        sets_catalog: list,
        parts_catalog: list,
        set_weights: list = None,
        part_weights: list = None,
    ) -> dict:
        order_id = str(uuid.uuid4())
        order_number = "WO" + str(random.randint(100000, 999999))

        order_date = self._pick_order_date()

        # Use customer's preferred source (80% of the time) or fall back to global weights
        preferred = customer.get("PreferredSource")
        if preferred and random.random() < 0.80:
            source = preferred
        else:
            source = random.choices(_SOURCE_OPTIONS, weights=_SOURCE_WEIGHTS, k=1)[0]

        # Resolve weights: prefer passed-in, fall back to precomputed, then uniform
        s_weights = set_weights or self._set_weights or None
        p_weights = part_weights or self._part_weights or None

        num_lines = self._get_num_lines(customer)
        lines = []

        for line_num in range(1, num_lines + 1):
            is_set = random.random() < 0.70

            if is_set and sets_catalog:
                item = random.choices(sets_catalog, weights=s_weights, k=1)[0]
                set_num = item.get("set_num", item.get("SetNum"))
                item_name = item.get("name", item.get("Name", ""))
                unit_price = round(float(np.random.lognormal(mean=3.5, sigma=0.7)), 2)
                unit_price = max(20.0, min(300.0, unit_price))
                quantity = random.randint(1, 5)
                line = {
                    "LineNumber": line_num,
                    "SetNum": set_num,
                    "PartNum": None,
                    "ItemName": item_name,
                    "Quantity": quantity,
                    "UnitPrice": unit_price,
                    "ExtendedPrice": round(quantity * unit_price, 2),
                }
            elif parts_catalog:
                item = random.choices(parts_catalog, weights=p_weights, k=1)[0]
                part_num = item.get("part_num", item.get("PartNum"))
                item_name = item.get("name", item.get("Name", ""))
                unit_price = round(float(np.random.lognormal(mean=0.0, sigma=0.8)), 2)
                unit_price = max(0.10, min(5.0, unit_price))
                quantity = random.randint(1, 50)
                line = {
                    "LineNumber": line_num,
                    "SetNum": None,
                    "PartNum": part_num,
                    "ItemName": item_name,
                    "Quantity": quantity,
                    "UnitPrice": unit_price,
                    "ExtendedPrice": round(quantity * unit_price, 2),
                }
            else:
                continue

            lines.append(line)

        order_total = round(sum(line["ExtendedPrice"] for line in lines), 2)

        order = {
            "OrderId": order_id,
            "OrderNumber": order_number,
            "OrderDate": order_date,
            "CustomerId": customer["CustomerId"],
            "ShippingCountry": customer["Country"],
            "Source": source,
            "OrderTotal": order_total,
            "OrderLines": lines,
        }
        return order
