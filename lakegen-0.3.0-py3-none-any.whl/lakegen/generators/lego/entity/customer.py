import random

import faker


def pick_customer_seed(max_customers: int) -> int:
    """Return a customer seed drawn from a power-law distribution.

    A small fraction of customers (~10%) generate ~50% of orders while
    most customers order only 1-2 times.  Lower seed values are heavily
    favored, making them repeat customers.
    """
    return int(max_customers * (random.random() ** 2.5))


class Customer:
    def __init__(self):
        self.faker = faker.Faker()

    def _generate_customer(self, seed=None):
        self.faker.seed_instance(seed)
        rng = self.faker.random

        country = rng.choices(
            ["US", "UK", "DE", "DK", "JP", "FR", "CA", "AU", "NL", "SE"],
            weights=[30, 15, 12, 10, 8, 5, 5, 5, 5, 5],
            k=1,
        )[0]

        loyalty_tier = rng.choices(
            ["Bronze", "Silver", "Gold", "VIP"],
            weights=[50, 30, 15, 5],
            k=1,
        )[0]

        member_since = self.faker.date_between(start_date="-10y", end_date="-30d")

        if country in ("US", "CA", "AU"):
            source_weights = [60, 30, 10]
        elif country == "JP":
            source_weights = [20, 70, 10]
        elif country in ("DK", "DE", "NL", "SE"):
            source_weights = [50, 25, 25]
        else:  # UK, FR
            source_weights = [45, 40, 15]

        preferred_source = rng.choices(
            ["Web", "Mobile", "InStore"],
            weights=source_weights,
            k=1,
        )[0]

        customer = {
            "CustomerId": str(self.faker.uuid4()),
            "Name": self.faker.name(),
            "Email": self.faker.email(),
            "Country": country,
            "LoyaltyTier": loyalty_tier,
            "MemberSince": member_since.isoformat(),
            "PreferredSource": preferred_source,
        }
        return customer
