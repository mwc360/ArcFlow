import random
import copy
from datetime import datetime, timedelta


class DataQualityInjector:
    """
    Injects realistic data quality issues into record batches.
    
    Designed for data engineering labs — students must detect and handle:
    - Late-arriving events (~2%): timestamps pushed back 1-48 hours
    - Duplicate records (~1%): same record appears twice (same PK)
    - Null fields (~0.5%): random non-PK fields set to None
    - Out-of-range values (~0.3%): numeric fields with extreme values
    """

    # Fields that should NEVER be nullified or duplicated (primary keys)
    PK_FIELDS = {
        "EventId", "TransactionId", "ProductionOrderId", "InspectionId",
        "ReturnId", "OrderId", "CustomerId",
    }

    # Numeric fields eligible for out-of-range injection
    NUMERIC_FIELDS = {
        "MoldTemp": (999.9, -50.0),       # way too hot or cold
        "InjectionPressure": (9999.0, -1.0),
        "CycleTimeMs": (999999, -100),
        "Quantity": (-9999, 0),
        "TargetQuantity": (-1, 0),
        "GoodQuantity": (-1, 0),
        "ClutchPowerScore": (99.9, -1.0),
        "RefundAmount": (-999.99, 99999.99),
    }

    def __init__(
        self,
        late_arrival_rate: float = 0.02,
        duplicate_rate: float = 0.01,
        null_rate: float = 0.005,
        out_of_range_rate: float = 0.003,
    ):
        self.late_arrival_rate = late_arrival_rate
        self.duplicate_rate = duplicate_rate
        self.null_rate = null_rate
        self.out_of_range_rate = out_of_range_rate

    def inject(self, records: list) -> list:
        """
        Apply data quality issues to a list of records. Returns a new list
        (may be larger due to duplicates).
        
        Args:
            records: List of dicts to inject issues into
            
        Returns:
            New list with issues injected (original records are not modified)
        """
        if not records:
            return records

        result = []
        
        for record in records:
            rec = copy.copy(record)  # shallow copy is fine for flat dicts
            
            # Late arrival: push Timestamp back
            if random.random() < self.late_arrival_rate:
                if "Timestamp" in rec and rec["Timestamp"]:
                    try:
                        ts = datetime.fromisoformat(rec["Timestamp"])
                        ts = ts - timedelta(hours=random.uniform(1, 48))
                        rec["Timestamp"] = ts.isoformat()
                    except (ValueError, TypeError):
                        pass
            
            # Null injection: pick a random non-PK field and null it
            if random.random() < self.null_rate:
                eligible = [k for k in rec.keys() if k not in self.PK_FIELDS and rec[k] is not None]
                if eligible:
                    rec[random.choice(eligible)] = None
            
            # Out-of-range: pick a numeric field and set extreme value
            if random.random() < self.out_of_range_rate:
                eligible = [k for k in rec.keys() if k in self.NUMERIC_FIELDS]
                if eligible:
                    field = random.choice(eligible)
                    bad_high, bad_low = self.NUMERIC_FIELDS[field]
                    rec[field] = random.choice([bad_high, bad_low])
            
            result.append(rec)
            
            # Duplicate: append the same record again
            if random.random() < self.duplicate_rate:
                result.append(copy.copy(rec))
        
        return result
