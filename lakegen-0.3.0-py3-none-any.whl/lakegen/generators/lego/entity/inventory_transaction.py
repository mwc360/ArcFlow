import random
import uuid
from datetime import datetime, timedelta

import numpy as np


TRANSACTION_TYPES = [
    "PRODUCTION_RECEIPT",  # Parts produced → added to inventory
    "ORDER_PICK",          # Parts picked for customer order → removed
    "SCRAP",              # Defective parts scrapped → removed
    "TRANSFER_IN",        # Parts transferred in from another line
    "TRANSFER_OUT",       # Parts transferred out to another line
    "ADJUSTMENT",         # Manual count correction (+ or -)
]


class InventoryTransaction:
    """Generates inventory transaction records for event-sourced ledger."""

    def generate_production_receipt(self, production_order: dict, production_lines: list) -> dict:
        """Generate an inventory receipt from a completed production order."""
        line = None
        for l in production_lines:
            if l["LineId"] == production_order.get("MachineId"):
                line = l
                break
        if not line:
            line = random.choice(production_lines)
        
        return {
            "TransactionId": str(uuid.uuid4()),
            "Timestamp": production_order.get("ActualEnd") or datetime.now().isoformat(),
            "PartNum": production_order.get("PartNum"),
            "ColorId": production_order.get("ColorId"),
            "LineId": line["LineId"],
            "TransactionType": "PRODUCTION_RECEIPT",
            "Quantity": production_order.get("GoodQuantity", 0),
            "ReferenceId": production_order.get("ProductionOrderId"),
            "ReferenceType": "production_order",
        }

    def generate_scrap(self, production_order: dict, production_lines: list) -> dict:
        """Generate a scrap transaction from a production order's rejects."""
        line = None
        for l in production_lines:
            if l["LineId"] == production_order.get("MachineId"):
                line = l
                break
        if not line:
            line = random.choice(production_lines)
        
        scrap_qty = production_order.get("ScrapQuantity", 0)
        if scrap_qty <= 0:
            return None
        
        return {
            "TransactionId": str(uuid.uuid4()),
            "Timestamp": production_order.get("ActualEnd") or datetime.now().isoformat(),
            "PartNum": production_order.get("PartNum"),
            "ColorId": production_order.get("ColorId"),
            "LineId": line["LineId"],
            "TransactionType": "SCRAP",
            "Quantity": -scrap_qty,  # negative = removed from inventory
            "ReferenceId": production_order.get("ProductionOrderId"),
            "ReferenceType": "production_order",
        }

    def generate_order_picks(self, order: dict, production_lines: list, colors_catalog: list = None) -> list:
        """
        Generate ORDER_PICK transactions for a web order's lines.
        Each order line becomes an inventory deduction.
        """
        picks = []
        # Pick from a random distribution line
        dist_lines = [l for l in production_lines if l.get("CellType") in ("packaging", "assembly")] or production_lines

        # Common LEGO color IDs weighted by real-world frequency
        common_color_weights = {
            0: 10, 15: 8, 71: 7, 1: 6, 4: 6, 14: 5,
            7: 5, 36: 4, 28: 3, 72: 3, 5: 3, 6: 2,
        }

        # Parse order date for pick timing offset
        order_date_raw = order.get("OrderDate", datetime.now().isoformat())
        if isinstance(order_date_raw, str):
            try:
                order_dt = datetime.fromisoformat(order_date_raw)
            except ValueError:
                order_dt = datetime.now()
        else:
            order_dt = order_date_raw

        for line_item in order.get("OrderLines", []):
            pick_line = random.choice(dist_lines)

            # Determine ColorId based on item type
            if line_item.get("SetNum"):
                # Sets are boxed products; use Black (0) as generic packaging color
                color_id = 0
            elif colors_catalog:
                # Weighted selection from catalog favoring common colors
                catalog_ids = [int(c.get("id", c.get("ColorId", 0))) for c in colors_catalog]
                weights = [common_color_weights.get(cid, 1) for cid in catalog_ids]
                color_id = random.choices(catalog_ids, weights=weights, k=1)[0]
            else:
                color_id = 0

            # Picks happen 1-8 hours after order placement (warehouse processing)
            pick_ts = order_dt + timedelta(hours=random.uniform(1, 8))

            picks.append({
                "TransactionId": str(uuid.uuid4()),
                "Timestamp": pick_ts.isoformat(),
                "PartNum": line_item.get("PartNum"),
                "ColorId": color_id,
                "LineId": pick_line["LineId"],
                "TransactionType": "ORDER_PICK",
                "Quantity": -line_item.get("Quantity", 1),  # negative = removed
                "ReferenceId": order.get("OrderId"),
                "ReferenceType": "web_order",
            })
        return picks

    def generate_transfer(self, parts_catalog: list, colors_catalog: list, production_lines: list) -> list:
        """Generate a pair of TRANSFER_OUT + TRANSFER_IN transactions."""
        part = random.choice(parts_catalog)
        color = random.choice(colors_catalog)
        # Lognormal: most transfers moderate (1000-5000), rare large ones (10000+)
        qty = int(np.clip(np.random.lognormal(mean=7.5, sigma=0.8), 200, 20000))
        
        from_line = random.choice(production_lines)
        to_line = random.choice([l for l in production_lines if l["LineId"] != from_line["LineId"]])
        
        ts = datetime.now() - timedelta(hours=random.randint(0, 48))
        ref_id = str(uuid.uuid4())  # shared reference for the pair
        
        return [
            {
                "TransactionId": str(uuid.uuid4()),
                "Timestamp": ts.isoformat(),
                "PartNum": part.get("part_num", part.get("PartNum")),
                "ColorId": int(color.get("id", color.get("ColorId", 0))),
                "LineId": from_line["LineId"],
                "TransactionType": "TRANSFER_OUT",
                "Quantity": -qty,
                "ReferenceId": ref_id,
                "ReferenceType": "manual",
            },
            {
                "TransactionId": str(uuid.uuid4()),
                "Timestamp": (ts + timedelta(minutes=random.randint(15, 120))).isoformat(),
                "PartNum": part.get("part_num", part.get("PartNum")),
                "ColorId": int(color.get("id", color.get("ColorId", 0))),
                "LineId": to_line["LineId"],
                "TransactionType": "TRANSFER_IN",
                "Quantity": qty,
                "ReferenceId": ref_id,
                "ReferenceType": "manual",
            },
        ]

    def generate_adjustment(self, parts_catalog: list, colors_catalog: list, production_lines: list) -> dict:
        """Generate a manual inventory count adjustment."""
        part = random.choice(parts_catalog)
        color = random.choice(colors_catalog)
        line = random.choice(production_lines)
        
        # Adjustments cluster around zero — most are tiny corrections
        qty = int(np.random.normal(0, 25))
        if qty == 0:
            qty = random.choice([-1, 1])
        
        return {
            "TransactionId": str(uuid.uuid4()),
            "Timestamp": (datetime.now() - timedelta(hours=random.randint(0, 72))).isoformat(),
            "PartNum": part.get("part_num", part.get("PartNum")),
            "ColorId": int(color.get("id", color.get("ColorId", 0))),
            "LineId": line["LineId"],
            "TransactionType": "ADJUSTMENT",
            "Quantity": qty,
            "ReferenceId": str(uuid.uuid4()),
            "ReferenceType": "manual",
        }
