import random
import uuid
from datetime import datetime, timedelta

import numpy as np


INSPECTOR_IDS = [f"QC-{i:03d}" for i in range(1, 11)]

QC_NOTES = [
    None, None, None, None, None,  # Most inspections have no notes
    "Mold wear detected - schedule resurfacing",
    "Color batch variance within acceptable limits",
    "Slight flash on runner side - monitor",
    "Clutch power trending low - check cavity alignment",
    "Surface finish degradation noted",
    "Foreign material contamination suspected",
    "Dimensional drift detected - recalibrate",
    "New material batch - initial qualification",
    "Post-maintenance verification pass",
    "Customer complaint follow-up inspection",
]


class QualityInspection:
    """Generates post-production quality inspection records."""

    def _generate_inspection(self, production_order: dict) -> dict:
        """
        Generate a QC inspection for a completed production order.
        
        Args:
            production_order: A production_order dict (must have ProductionOrderId, ActualEnd)
        
        Returns:
            Dict with inspection fields
        """
        # Inspection happens 15-120 minutes after production ends
        end_time = production_order.get("ActualEnd")
        if end_time:
            try:
                base_time = datetime.fromisoformat(end_time)
            except (ValueError, TypeError):
                base_time = datetime.now()
        else:
            base_time = datetime.now()
        
        inspection_time = base_time + timedelta(minutes=random.randint(15, 120))
        
        # Sample size: 50-200 units
        sample_size = random.randint(50, 200)
        
        # Clutch power: normal distribution (mean=3.2N, std=0.3)
        clutch_power = round(float(np.random.normal(3.2, 0.3)), 3)
        
        # Dimensional accuracy: deviation in mm (mean=0, std=0.02)
        dimensional_accuracy = round(float(np.random.normal(0.0, 0.02)), 4)
        
        # Color consistency: Delta-E (lower=better, lognormal, most < 2.0)
        color_consistency = round(float(np.random.lognormal(-0.5, 0.7)), 3)
        
        # Determine pass/fail
        # Fail conditions: clutch power out of range, dimensional too far off, color too inconsistent
        fail_reasons = []
        if clutch_power < 2.5 or clutch_power > 4.0:
            fail_reasons.append("clutch_power")
        if abs(dimensional_accuracy) > 0.05:
            fail_reasons.append("dimensional")
        if color_consistency > 3.0:
            fail_reasons.append("color")
        
        if fail_reasons:
            # ~8% actual failure rate
            if random.random() < 0.7:  # 70% of out-of-spec are real failures
                result = "FAIL"
                fail_count = random.randint(int(sample_size * 0.05), int(sample_size * 0.4))
            else:
                result = "CONDITIONAL"
                fail_count = random.randint(1, int(sample_size * 0.05))
        else:
            if random.random() < 0.02:  # 2% random failures even with good metrics
                result = "FAIL"
                fail_count = random.randint(1, int(sample_size * 0.1))
            else:
                result = "PASS"
                fail_count = random.randint(0, max(1, int(sample_size * 0.01)))
        
        pass_count = sample_size - fail_count
        
        return {
            "InspectionId": str(uuid.uuid4()),
            "ProductionOrderId": production_order.get("ProductionOrderId"),
            "Timestamp": inspection_time.isoformat(),
            "InspectorId": random.choice(INSPECTOR_IDS),
            "SampleSize": sample_size,
            "PassCount": pass_count,
            "FailCount": fail_count,
            "ClutchPowerScore": clutch_power,
            "DimensionalAccuracy": dimensional_accuracy,
            "ColorConsistency": color_consistency,
            "Result": result,
            "Notes": random.choice(QC_NOTES),
        }
