import random
import uuid
from datetime import datetime, timedelta
import numpy as np


class ProductionOrder:
    """Generates production orders for LEGO part manufacturing."""

    STATUSES = ["scheduled", "in_progress", "completed", "cancelled"]
    SHIFTS = ["A", "B", "C"]  # 8-hour shifts

    def _generate_production_order(self, parts_catalog: list, colors_catalog: list, molds: list, production_lines: list) -> dict:
        """
        Generate a single production order.
        
        Args:
            parts_catalog: List of part dicts (from parquet)
            colors_catalog: List of color dicts (from parquet)
            molds: List of mold dicts (from production_line.py)
            production_lines: List of production line dicts
        
        Returns:
            Dict with production order fields
        """
        part = random.choice(parts_catalog)
        color = random.choice(colors_catalog)
        
        # Pick an active mold (or any mold)
        active_molds = [m for m in molds if m.get("Status") == "active"]
        mold = random.choice(active_molds) if active_molds else random.choice(molds)
        
        # Pick an injection molding line
        molding_lines = [l for l in production_lines if l.get("CellType") == "injection_molding"]
        line = random.choice(molding_lines) if molding_lines else random.choice(production_lines)
        
        # Target quantity: lognormal distribution centered around 20k-50k
        target_qty = int(np.random.lognormal(mean=10.2, sigma=0.5))
        target_qty = max(5000, min(target_qty, 100_000))
        
        # Status with weighted probability
        status = random.choices(
            self.STATUSES,
            weights=[10, 15, 70, 5],  # Most are completed
        )[0]
        
        # Timing
        scheduled_start = datetime.now() - timedelta(hours=random.randint(1, 168))  # within last week
        
        actual_start = None
        actual_end = None
        good_qty = 0
        scrap_qty = 0
        
        if status in ("in_progress", "completed", "cancelled"):
            # Started slightly after scheduled (0-2 hours delay)
            actual_start = scheduled_start + timedelta(minutes=random.randint(0, 120))
        
        if status == "completed":
            # Duration based on quantity and cavity count
            cavities = mold.get("CavityCount", 4)
            cycle_time_sec = 12  # ~12 seconds per injection cycle
            production_hours = (target_qty / cavities * cycle_time_sec) / 3600
            actual_end = actual_start + timedelta(hours=production_hours * random.uniform(0.9, 1.2))
            
            # Yield: 95-100% good, rest is scrap
            yield_rate = random.uniform(0.95, 1.0)
            good_qty = int(target_qty * yield_rate)
            scrap_qty = target_qty - good_qty
        elif status == "in_progress":
            # Partial progress
            progress = random.uniform(0.1, 0.9)
            good_qty = int(target_qty * progress * random.uniform(0.96, 1.0))
            scrap_qty = int(target_qty * progress) - good_qty
        elif status == "cancelled":
            # May have some partial output
            if random.random() < 0.3:
                good_qty = int(target_qty * random.uniform(0.05, 0.3))
                scrap_qty = random.randint(0, int(good_qty * 0.05))
        
        order_date = scheduled_start.strftime("%Y%m%d")
        seq = random.randint(1, 9999)
        
        return {
            "ProductionOrderId": str(uuid.uuid4()),
            "OrderNumber": f"PO-{order_date}-{seq:04d}",
            "PartNum": part.get("part_num", part.get("PartNum")),
            "ColorId": int(color.get("id", color.get("ColorId", 0))),
            "MoldId": mold["MoldId"],
            "MachineId": line["LineId"],
            "TargetQuantity": target_qty,
            "GoodQuantity": good_qty,
            "ScrapQuantity": scrap_qty,
            "Status": status,
            "ScheduledStart": scheduled_start.isoformat(),
            "ActualStart": actual_start.isoformat() if actual_start else None,
            "ActualEnd": actual_end.isoformat() if actual_end else None,
            "ShiftId": random.choice(self.SHIFTS),
        }
