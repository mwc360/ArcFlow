import time
import random
import zlib
import socket
import logging
from faker import Faker

from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import posixpath
from typing import Optional
import fsspec

from lakegen.generators.base import BaseGenerator
from lakegen.writers import OutputWriterFactory

from .entity.shipment import Shipment
from .entity.customer import Customer
from .entity.order import Order
from .entity.item import Item

from .entity import shipment_lookups as lookups

logger = logging.getLogger(__name__)

# Initialize Faker
fake = Faker()


class McMillanDataGen(BaseGenerator):
    TABLES = [
        "shipment",
        "shipment_scan_event",
        "order",
        "customer",
        "item",
        "route",
        "servicelevel",
        "facility",
        "exceptiontype",
    ]

    def __init__(
        self,
        target_folder_uri: str = None,
        output_type_map: Optional[dict] = None,
        kafka_connection_string: Optional[str] = None,
        concurrenct_threads: int = 1,
        sec_delay_between_batches: int = None,
        max_events_per_second: int = None,
    ):
        super().__init__(target_folder_uri)
        self.output_type_map = output_type_map or {}
        self.kafka_connection_string = kafka_connection_string
        self.concurrenct_threads = concurrenct_threads
        self.sec_delay_between_batches = sec_delay_between_batches
        self.max_events_per_second = max_events_per_second
        
        # Create output writer factory
        self._writer_factory = OutputWriterFactory(
            target_folder_uri=target_folder_uri,
            kafka_connection_string=kafka_connection_string,
            system_id=None  # Will be set after _system_id is initialized
        )
        
        # Create directories for file-based outputs
        if target_folder_uri and self.fs:
            for table in self.TABLES:
                output_type = self.output_type_map.get(table, "json")
                if output_type in ["json", "parquet"]:
                    self.fs.mkdirs(posixpath.join(self.target_folder_uri, table), exist_ok=True)

        # Thread control
        self._telemetry_threads = []
        self._telemetry_stop = threading.Event()
        self._telemetry_start_time = None
        self._total_shipment_count = 0
        self._total_scan_event_count = 0
        self._total_order_count = 0
        self._system_id = zlib.crc32(socket.gethostname().encode()) & 0xFFFFFFFF
        self._item_catalog = Item().generate_items(count=500)
        self._customer_id_set = set()  # Use set for O(1) lookups instead of O(n)

        # Thread-safe locks for shared resources
        self._item_catalog_lock = threading.Lock()
        self._customer_set_lock = threading.Lock()
        
        # Update factory with system_id now that it's initialized
        self._writer_factory.system_id = self._system_id

    def _write_output_data(
        self,
        folder_uri: str,
        table_name: str,
        format: str,
        data: list,
        skip_if_non_empty_root: bool = False,
    ):
        if self.output_type_map.get(table_name, 1) is None:
            return None # skip write if output type is None
        
        # Check if we should skip file-based writes for static data
        if skip_if_non_empty_root and format in ["json", "parquet"] and self.fs:
            table_folder_uri = posixpath.join(folder_uri, table_name)
            try:
                existing_file_count = len(self.fs.ls(table_folder_uri))
            except FileNotFoundError:
                existing_file_count = 0
                pass
            if existing_file_count > 0:
                return None  # skip write, i.e. static reference data already exists
        
        # Get writer from factory
        format = format.lower()
        try:
            writer = self._writer_factory.get_writer(format)
        except ValueError as e:
            raise ValueError(f"Error getting writer for format '{format}': {e}")
        
        # Write data using the appropriate writer
        ts = int(time.time() * 1000)
        
        return writer.write(table_name=table_name, data=data, timestamp=ts)

    def _write_static_reference_data(self):
        """Write static reference data files."""
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="item",
            format=self.output_type_map.get("item", "json"),
            data=self._item_catalog,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="route",
            format=self.output_type_map.get("route", "json"),
            data=lookups.ROUTES,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="servicelevel",
            format=self.output_type_map.get("servicelevel", "json"),
            data=lookups.SERVICE_LEVELS,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="facility",
            format=self.output_type_map.get("facility", "json"),
            data=lookups.FACILITIES,
            skip_if_non_empty_root=True,
        )
        self._write_output_data(
            folder_uri=self.target_folder_uri,
            table_name="exceptiontype",
            format=self.output_type_map.get("exceptiontype", "json"),
            data=lookups.EXCEPTION_TYPES,
            skip_if_non_empty_root=True,
        )

    def _start_generator_thread(self, verbose=True):
        """Worker function to send telemetry until stop event is set."""
        total_scan_event_count = 0
        start_time = time.time()

        try:
            logger.info("[%s] Starting generator thread...", threading.current_thread().name)
            logger.debug("[%s] Stop event is set: %s", threading.current_thread().name, self._telemetry_stop.is_set())

            while not self._telemetry_stop.is_set():
                (
                    shipment_buffer,
                    scan_event_buffer,
                    order_buffer,
                    customer_buffer,
                    item_buffer,
                ) = [], [], [], [], []

                shipment_instance = Shipment()

                max_customers = min(
                    max(int(self._total_shipment_count**0.6), 10), 99_999_999
                )
                # TODO: move seed to input parameter to cascade down to all faker instances

                customer_instance = Customer()
                order_instance = Order()
                item_instance = Item()

                if random.random() < 0.02:
                    items = item_instance.generate_items(count=10)
                    item_buffer.extend(items)
                    with self._item_catalog_lock:
                        self._item_catalog.extend(items)

                # create a random batch
                for _ in range(1, random.randint(10, 50)):
                    customer_seed = random.randint(int(1), int(max_customers))
                    customer = customer_instance._generate_customer(seed=customer_seed)

                    # don't recreate the same customer
                    with self._customer_set_lock:
                        if customer["CustomerId"] not in self._customer_id_set:
                            self._customer_id_set.add(customer["CustomerId"])
                            customer_buffer.append(customer)

                    # create order for customer
                    with self._item_catalog_lock:
                        order = order_instance._generate_order(
                            customer, self._item_catalog
                        )
                    order_buffer.append(order)

                    # for each order line, create shipment and events

                    def _process_order_lines(customer, order_id, order_lines: list):
                        shipment = shipment_instance._generate_shipment(
                            customer, order_id, order_lines
                        )
                        shipment_events = shipment_instance._generate_shipment_event(
                            shipment
                        )
                        shipment_buffer.append(shipment)
                        scan_event_buffer.extend(shipment_events)

                    order_line_buffer = []
                    for index, order_line in enumerate(order["OrderLines"]):
                        # chance of order lines being shipped together
                        if (
                            random.random() > 0.4
                            or index == len(order["OrderLines"]) - 1
                        ):
                            order_line_buffer.append(order_line)
                            _process_order_lines(
                                customer, order["OrderId"], order_line_buffer
                            )
                            order_line_buffer = []
                        else:
                            order_line_buffer.append(order_line)

                # Auto-tuning throttling: control event generation rate after first batch
                if self.max_events_per_second is not None and total_scan_event_count > 0:
                    # Calculate per-thread target EPS
                    max_thread_eps = self.max_events_per_second / max(1, self.concurrenct_threads)
                    
                    # Calculate how many events we just generated
                    batch_scan_event_count = len(scan_event_buffer)
                    
                    # Calculate how long this batch SHOULD take at target rate
                    target_time_for_batch = batch_scan_event_count / max_thread_eps
                    
                    # Always sleep for the target time to maintain steady rate
                    # This prevents spiky behavior and maintains consistent throughput
                    if verbose:
                        elapsed_time = time.time() - start_time
                        current_eps = total_scan_event_count / elapsed_time if elapsed_time > 0 else 0
                        logger.info(
                            "[%s] Throttling: current_eps=%.2f, target=%.2f, sleeping %.3fs for %d events",
                            threading.current_thread().name, current_eps, max_thread_eps,
                            target_time_for_batch, batch_scan_event_count,
                        )
                    time.sleep(target_time_for_batch)

                if len(item_buffer) > 0:
                    self._write_output_data(
                        folder_uri=self.target_folder_uri,
                        table_name="item",
                        format=self.output_type_map.get("item", "json"),
                        data=item_buffer,
                    )
                if len(customer_buffer) > 0:
                    self._write_output_data(
                        folder_uri=self.target_folder_uri,
                        table_name="customer",
                        format=self.output_type_map.get("customer", "json"),
                        data=customer_buffer,
                    )
                self._write_output_data(
                    folder_uri=self.target_folder_uri,
                    table_name="order",
                    format=self.output_type_map.get("order", "json"),
                    data=order_buffer,
                )
                self._write_output_data(
                    folder_uri=self.target_folder_uri,
                    table_name="shipment",
                    format=self.output_type_map.get("shipment", "json"),
                    data=shipment_buffer,
                )
                self._write_output_data(
                    folder_uri=self.target_folder_uri,
                    table_name="shipment_scan_event",
                    format=self.output_type_map.get("shipment_scan_event", "json"),
                    data=scan_event_buffer,
                )

                batch_order_count = len(order_buffer)
                self._total_order_count += batch_order_count
                batch_shipment_count = len(shipment_buffer)
                self._total_shipment_count += (
                    batch_shipment_count
                )
                batch_scan_event_count = len(scan_event_buffer)
                total_scan_event_count += batch_scan_event_count
                self._total_scan_event_count += batch_scan_event_count
                elapsed_time = time.time() - start_time
                eps = total_scan_event_count / elapsed_time if elapsed_time > 0 else 0

                if verbose:
                    logger.info(
                        "[%s] Batch complete - Shipments: %d, Orders: %d, "
                        "Customers: %d, Items: %d, Scan Events: %d | "
                        "Total Scan Events: %d, EPS: %.2f",
                        threading.current_thread().name, batch_shipment_count, batch_order_count,
                        len(customer_buffer), len(item_buffer), batch_scan_event_count,
                        total_scan_event_count, eps,
                    )

                if self.sec_delay_between_batches:
                    time.sleep(self.sec_delay_between_batches)

        except Exception:
            logger.error("[%s] Generator thread failed", threading.current_thread().name, exc_info=True)
            raise
        else:
            elapsed_time = time.time() - start_time
            eps = total_scan_event_count / elapsed_time if elapsed_time > 0 else 0
            return total_scan_event_count, eps

    def start(self, verbose=True, background=True):
        """
        Start telemetry producer.

        Args:
            concurrency: Number of concurrent worker threads
            verbose: Print progress messages
            background: If True, run in background thread. If False, block until interrupted.

        Returns:
            (total_events, total_eps) if background=False, otherwise None
        """
        if self._telemetry_threads and any(
            t.is_alive() for t in self._telemetry_threads
        ):
            logger.warning("Generator already running.")
            return

        # write static reference data
        self._write_static_reference_data()

        # Clear stop event for new run
        self._telemetry_stop.clear()
        self._total_scan_event_count = 0  # Reset counter
        self._telemetry_start_time = time.time()  # Record start time

        def _runner():
            results = []
            start_time = time.time()

            with ThreadPoolExecutor(max_workers=self.concurrenct_threads) as executor:
                futures = [
                    executor.submit(self._start_generator_thread, verbose)
                    for _ in range(self.concurrenct_threads)
                ]
                try:
                    for future in as_completed(futures):
                        results.append(future.result())
                except KeyboardInterrupt:
                    logger.info("Background thread received interrupt. Stopping all workers...")
                    self._telemetry_stop.set()
                    for future in futures:
                        try:
                            results.append(future.result())
                        except Exception:
                            logger.error("Thread terminated with error", exc_info=True)

            total_events = sum(r[0] for r in results) if results else 0
            total_elapsed = time.time() - start_time
            total_eps = total_events / total_elapsed if total_elapsed > 0 else 0
            logger.info("[Runner] exited: total_events=%d, eps=%.2f", total_events, total_eps)

        if background:
            # Run in background thread
            thread = threading.Thread(target=_runner, name="Runner", daemon=False)
            thread.start()
            self._telemetry_threads = [thread]
            logger.info("Generator started in background with %d concurrent worker(s).", self.concurrenct_threads)
            logger.info("Call gen.stop() to stop generation.")
        else:
            # Run in foreground (blocking)
            logger.info("Generator starting with %d concurrent worker(s).", self.concurrenct_threads)
            logger.info("Interrupt the process to stop generation.")

            _runner()

    def stop(self, timeout=10):
        """Signal the background producer to stop and join all threads."""
        if not self._telemetry_threads:
            logger.info("Generator not running.")
            return

        logger.info("Stopping generator...")
        self._telemetry_stop.set()

        for thread in self._telemetry_threads:
            thread.join(timeout=timeout)
            if thread.is_alive():
                logger.warning(
                    "Thread %s is taking longer to stop; it will exit after the current batch.",
                    thread.name,
                )

        if not any(t.is_alive() for t in self._telemetry_threads):
            logger.info("Generator stopped.")

        self._telemetry_threads = []
        
        # Close all writers
        self._writer_factory.close_all()

    def status(self):
        """Check if telemetry is currently running and print metrics."""
        is_running = bool(self._telemetry_threads) and any(
            t.is_alive() for t in self._telemetry_threads
        )

        if is_running:
            elapsed_time = (
                time.time() - self._telemetry_start_time
                if self._telemetry_start_time
                else 0
            )
            eps = self._total_scan_event_count / elapsed_time if elapsed_time > 0 else 0
            logger.info(
                "Generator running: total_events=%d, eps=%.2f, elapsed=%.1fs",
                self._total_scan_event_count, eps, elapsed_time,
            )
        else:
            logger.info("Generator not running.")

        return is_running
