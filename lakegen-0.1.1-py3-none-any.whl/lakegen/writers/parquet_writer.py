import posixpath
import fsspec
import pandas as pd
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from .base import BaseWriter


class ParquetWriter(BaseWriter):
    """Writer for Parquet file output"""
    
    def __init__(self, target_folder_uri: str, system_id: int):
        """
        Initialize Parquet writer.
        
        Args:
            target_folder_uri: Base folder URI for output
            system_id: System/organization ID for metadata
        """
        self.target_folder_uri = target_folder_uri
        self.system_id = system_id
        self.fs, self._fs_path = fsspec.core.url_to_fs(target_folder_uri)
    
    def write(
        self, 
        table_name: str, 
        data: List[Dict[str, Any]], 
        timestamp: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Write data to Parquet file.
        
        Args:
            table_name: Name of the table
            data: List of records to write
            timestamp: Optional timestamp for filename (defaults to current time)
            
        Returns:
            File URI of written file
        """
        import time
        import pyarrow as pa
        import pyarrow.parquet as pq
        
        if timestamp is None:
            timestamp = int(time.time() * 1000)
        
        # Add standard columns
        data = self._add_standard_columns(data)
        
        table_folder_uri = posixpath.join(self.target_folder_uri, table_name)
        file_uri = posixpath.join(table_folder_uri, f"{table_name}_{timestamp}.parquet")
        
        table = pa.Table.from_pandas(pd.DataFrame(data))
        
        # Use fsspec to write the parquet file to support abfss:// and other protocols
        with fsspec.open(file_uri, 'wb') as f:
            pq.write_table(table, f)
        
        return file_uri
    
    def _add_standard_columns(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Add standard metadata columns to each record."""
        timestamp = self._now_utc_iso()
        for record in data:
            record["OrganizationId"] = self.system_id
            record["GeneratedAt"] = timestamp
        return data
    
    def _now_utc_iso(self) -> str:
        """Get current UTC timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()
    
    def close(self):
        """No cleanup needed for Parquet writer"""
        pass
