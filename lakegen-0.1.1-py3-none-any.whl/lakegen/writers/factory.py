from typing import Dict, Optional
from .base import BaseWriter
from .json_writer import JsonWriter
from .parquet_writer import ParquetWriter
from .kafka_writer import KafkaWriter


class OutputWriterFactory:
    """Factory for creating output writers based on type"""
    
    def __init__(
        self,
        target_folder_uri: Optional[str] = None,
        kafka_connection_string: Optional[str] = None,
        system_id: Optional[int] = None
    ):
        """
        Initialize the factory with configuration.
        
        Args:
            target_folder_uri: Base folder URI for file-based outputs (json, parquet)
            kafka_connection_string: Kafka/EventHub connection string for kafka output
            system_id: System/organization ID for metadata
        """
        self.target_folder_uri = target_folder_uri
        self.kafka_connection_string = kafka_connection_string
        self.system_id = system_id
        
        # Cache writers to reuse connections (especially for Kafka)
        self._writer_cache: Dict[str, BaseWriter] = {}
    
    def get_writer(self, output_type: str) -> BaseWriter:
        """
        Get a writer instance for the specified output type.
        
        Args:
            output_type: Type of output ("json", "parquet", "kafka")
            
        Returns:
            Writer instance
            
        Raises:
            ValueError: If output_type is invalid or required configuration is missing
        """
        output_type = output_type.lower()
        
        # Return cached writer if available
        if output_type in self._writer_cache:
            return self._writer_cache[output_type]
        
        # Create new writer based on type
        if output_type == "json":
            if not self.target_folder_uri:
                raise ValueError("target_folder_uri is required for JSON output")
            writer = JsonWriter(self.target_folder_uri, self.system_id)
            
        elif output_type == "parquet":
            if not self.target_folder_uri:
                raise ValueError("target_folder_uri is required for Parquet output")
            writer = ParquetWriter(self.target_folder_uri, self.system_id)
            
        elif output_type == "kafka":
            if not self.kafka_connection_string:
                raise ValueError("kafka_connection_string is required for Kafka output")
            writer = KafkaWriter(self.kafka_connection_string, self.system_id)
            
        else:
            raise ValueError(f"Unsupported output type: {output_type}")
        
        # Cache the writer
        self._writer_cache[output_type] = writer
        
        return writer
    
    def close_all(self):
        """Close all cached writers and clean up resources"""
        for writer in self._writer_cache.values():
            try:
                writer.close()
            except Exception as e:
                print(f"Error closing writer: {e}")
        
        self._writer_cache.clear()
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - clean up writers"""
        self.close_all()
        return False
