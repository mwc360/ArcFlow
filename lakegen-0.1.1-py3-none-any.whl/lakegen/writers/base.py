from abc import ABC, abstractmethod
from typing import List, Dict, Any


class BaseWriter(ABC):
    """Base class for output writers (JSON, Parquet, Kafka, etc.)"""
    
    @abstractmethod
    def write(self, table_name: str, data: List[Dict[str, Any]], **kwargs) -> Any:
        """
        Write data to the target output.
        
        Args:
            table_name: Name of the table/topic
            data: List of records to write
            **kwargs: Additional writer-specific parameters
            
        Returns:
            Writer-specific return value (file path, message ID, etc.)
        """
        pass
    
    @abstractmethod
    def close(self):
        """Clean up resources (close connections, flush buffers, etc.)"""
        pass
