import json
import re
import time
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from kafka import KafkaProducer
from kafka.errors import KafkaError
from .base import BaseWriter


class KafkaWriter(BaseWriter):
    """Writer for Kafka message output with EventHub support"""
    
    def __init__(self, connection_string: str, system_id: int):
        """
        Initialize Kafka writer.
        
        Args:
            connection_string: EventHub/Kafka connection string
            system_id: System/organization ID for metadata
        """
        self.system_id = system_id
        self.connection_string = connection_string
        
        # Parse connection string
        config = self._parse_connection_string(connection_string)
        
        # Store the topic from EntityPath (EventHub requirement)
        self.topic = config['topic']
        
        # Initialize Kafka producer with EventHub-compatible settings
        self.producer = KafkaProducer(
            bootstrap_servers=config['bootstrap_servers'],
            security_protocol='SASL_SSL',
            sasl_mechanism='PLAIN',
            sasl_plain_username=config['username'],
            sasl_plain_password=config['password'],
            value_serializer=lambda v: json.dumps(v).encode('utf-8'),
            compression_type=None,  # Disable compression for EventHub compatibility
            retries=3,
            max_in_flight_requests_per_connection=5,
            request_timeout_ms=30000,
            max_request_size=5242880,  # 5MB max message size
            buffer_memory=33554432,  # 32MB buffer
            api_version=(0, 10, 1)
        )
    
    def _parse_connection_string(self, connection_string: str) -> Dict[str, str]:
        """
        Parse EventHub connection string.
        
        Expected format:
        Endpoint=sb://namespace.servicebus.windows.net/;SharedAccessKeyName=key_name;SharedAccessKey=key_value;EntityPath=topic_name
        
        Args:
            connection_string: EventHub connection string
            
        Returns:
            Dict with bootstrap_servers, username, password, topic
        """
        parts = {}
        for part in connection_string.split(';'):
            if '=' in part:
                key, value = part.split('=', 1)
                parts[key] = value
        
        # Extract bootstrap server from Endpoint
        endpoint = parts.get('Endpoint', '')
        match = re.search(r'sb://([^/]+)', endpoint)
        if not match:
            raise ValueError(f"Invalid connection string format: missing Endpoint")
        
        bootstrap_servers = f"{match.group(1)}:9093"
        
        # Extract credentials
        key_name = parts.get('SharedAccessKeyName', '')
        key_value = parts.get('SharedAccessKey', '')
        
        if not key_name or not key_value:
            raise ValueError("Invalid connection string: missing SharedAccessKeyName or SharedAccessKey")
        
        # Extract EntityPath (topic name for EventHub)
        topic = parts.get('EntityPath', '')
        if not topic:
            raise ValueError("Invalid connection string: missing EntityPath (topic name)")
        
        # EventHub uses $ConnectionString as username
        username = f"$ConnectionString"
        # Password is the full connection string
        password = connection_string
        
        return {
            'bootstrap_servers': bootstrap_servers,
            'username': username,
            'password': password,
            'topic': topic
        }
    
    def write(
        self, 
        table_name: str, 
        data: List[Dict[str, Any]], 
        **kwargs
    ) -> Optional[List[Any]]:
        """
        Write data batch to Kafka topic.
        Splits large batches into multiple messages to respect EventHub 1MB limit.
        
        Args:
            table_name: Name of the table (used in metadata, NOT as topic name)
            data: List of records to write
            
        Returns:
            List of record metadata from Kafka producer
        """
        if not data:
            return None
        
        # Add standard columns
        data = self._add_standard_columns(data)
        
        # Split data into chunks if needed (to respect EventHub 1MB limit)
        # Estimate: ~100-150 records per message depending on record size
        max_records_per_message = 100
        results = []
        
        for i in range(0, len(data), max_records_per_message):
            chunk = data[i:i + max_records_per_message]
            
            # Create message payload with metadata wrapper
            payload = {
                "_meta": {
                    "schemaVersion": "1.0",
                    "producer": "lakegen.mcmillan",
                    "recordType": table_name,  # table_name is in metadata
                    "enqueuedTime": self._now_utc_iso(),
                    "batchIndex": i // max_records_per_message,
                    "batchSize": len(chunk),
                    "totalRecords": len(data)
                },
                "data": chunk,
            }
            
            # Use the EntityPath topic from connection string (not table_name)
            # This is required for EventHub which only supports one topic per connection
            topic = self.topic
            
            try:
                # Send message
                future = self.producer.send(topic, value=payload)
                
                # Wait for acknowledgment with timeout
                record_metadata = future.get(timeout=30)
                results.append(record_metadata)
                
            except KafkaError as e:
                print(f"Failed to send message to topic {topic}: {e}")
                raise
        
        return results
    
    def _add_standard_columns(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Add standard metadata columns to each record."""
        timestamp = self._now_utc_iso()
        for record in data:
            record["OrganizationId"] = self.system_id
            record["GeneratedAt"] = timestamp
        return data
    
    def _now_utc_iso(self) -> str:
        """Get current UTC timestamp in ISO format."""
        return datetime.now(timezone.utc).isoformat()
    
    def flush(self):
        """Flush any pending messages"""
        self.producer.flush()
    
    def close(self):
        """Close Kafka producer and clean up resources"""
        if hasattr(self, 'producer'):
            self.producer.flush()
            self.producer.close()
